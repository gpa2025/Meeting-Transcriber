# PowerShell script to install Meeting Transcriber
# This script must be run as administrator

# Check if running as administrator
if (-NOT ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Host "This script must be run as Administrator. Please restart with elevated privileges." -ForegroundColor Red
    Write-Host "Right-click on the script and select 'Run as Administrator'." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit
}

Write-Host "====================================================" -ForegroundColor Cyan
Write-Host "Meeting Transcriber Installer" -ForegroundColor Cyan
Write-Host "====================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "This script will:" -ForegroundColor White
Write-Host "1. Install the certificate to your trusted root store" -ForegroundColor White
Write-Host "2. Install the Meeting Transcriber application" -ForegroundColor White
Write-Host "3. Create shortcuts for easy access" -ForegroundColor White
Write-Host ""

# Get the current directory
 = Split-Path -Parent System.Management.Automation.InvocationInfo.MyCommand.Path
C:\Users\gianpaoa\Desktop\GitRepo\meeting_transcriber\installer\MeetingTranscriberCert.pfx = Join-Path  "MeetingTranscriberCert.cer"
C:\Users\gianpaoa\Desktop\GitRepo\meeting_transcriber\dist\MeetingTranscriber.msix = Join-Path  "MeetingTranscriber.msix"

# Check if files exist
if (-not (Test-Path C:\Users\gianpaoa\Desktop\GitRepo\meeting_transcriber\installer\MeetingTranscriberCert.pfx)) {
    Write-Host "Error: Certificate not found at C:\Users\gianpaoa\Desktop\GitRepo\meeting_transcriber\installer\MeetingTranscriberCert.pfx" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit
}

if (-not (Test-Path C:\Users\gianpaoa\Desktop\GitRepo\meeting_transcriber\dist\MeetingTranscriber.msix)) {
    Write-Host "Error: MSIX package not found at C:\Users\gianpaoa\Desktop\GitRepo\meeting_transcriber\dist\MeetingTranscriber.msix" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit
}

# Install certificate to trusted root store
Write-Host "Installing certificate..." -ForegroundColor Cyan
try {
    Import-Certificate -FilePath C:\Users\gianpaoa\Desktop\GitRepo\meeting_transcriber\installer\MeetingTranscriberCert.pfx -CertStoreLocation Cert:\LocalMachine\Root | Out-Null
    Write-Host "Certificate installed successfully." -ForegroundColor Green
} catch {
    Write-Host "Error installing certificate: " -ForegroundColor Red
    Write-Host "Trying alternative method..." -ForegroundColor Yellow
    
    try {
        certutil -addstore -f "ROOT" C:\Users\gianpaoa\Desktop\GitRepo\meeting_transcriber\installer\MeetingTranscriberCert.pfx | Out-Null
        Write-Host "Certificate installed successfully using certutil." -ForegroundColor Green
    } catch {
        Write-Host "Failed to install certificate. Error: " -ForegroundColor Red
        Read-Host "Press Enter to exit"
        exit
    }
}

# Wait a moment for certificate to be fully registered
Write-Host "Waiting for certificate to register..." -ForegroundColor Cyan
Start-Sleep -Seconds 3

# Install MSIX package with multiple fallback methods
Write-Host "Installing Meeting Transcriber..." -ForegroundColor Cyan
try {
    Add-AppxPackage -Path C:\Users\gianpaoa\Desktop\GitRepo\meeting_transcriber\dist\MeetingTranscriber.msix
    Write-Host "Standard installation successful." -ForegroundColor Green
} catch {
    Write-Host "Standard installation failed, trying with -AllowUntrusted flag..." -ForegroundColor Yellow
    try {
        Add-AppxPackage -Path C:\Users\gianpaoa\Desktop\GitRepo\meeting_transcriber\dist\MeetingTranscriber.msix -AllowUntrusted
        Write-Host "Installation with -AllowUntrusted successful." -ForegroundColor Green
    } catch {
        Write-Host "Installation failed with error:" -ForegroundColor Red
        Write-Host .Exception.Message -ForegroundColor Red
        
        Write-Host "Trying to register the package directly..." -ForegroundColor Yellow
        try {
            Add-AppxPackage -Register -Path C:\Users\gianpaoa\Desktop\GitRepo\meeting_transcriber\dist\MeetingTranscriber.msix -AllowUntrusted
            Write-Host "Direct registration successful." -ForegroundColor Green
        } catch {
            Write-Host "All installation methods failed. Error: " -ForegroundColor Red
            Read-Host "Press Enter to exit"
            exit
        }
    }
}

# Create desktop shortcut
Write-Host "Creating desktop shortcut..." -ForegroundColor Cyan
try {
     = New-Object -ComObject WScript.Shell
     = .CreateShortcut([System.Environment]::GetFolderPath('Desktop') + '\Meeting Transcriber.lnk')
    .TargetPath = "C:\WINDOWS\explorer.exe"
    .Arguments = "shell:AppsFolder\GPA.MeetingTranscriber_1.0.0.0_x64__1234567890abc"
    .IconLocation = "C:\WINDOWS\System32\SHELL32.dll,77"
    .Save()
    Write-Host "Desktop shortcut created successfully." -ForegroundColor Green
} catch {
    Write-Host "Failed to create desktop shortcut: " -ForegroundColor Yellow
    Write-Host "You can still launch the app from the Start menu or using LaunchApp.bat" -ForegroundColor Yellow
}

# Create Start Menu shortcut
Write-Host "Creating Start Menu shortcut..." -ForegroundColor Cyan
try {
     = [Environment]::GetFolderPath('ApplicationData')
     = Join-Path  'Microsoft\Windows\Start Menu\Programs'
     = Join-Path  'Meeting Transcriber.lnk'
     = New-Object -ComObject WScript.Shell
     = .CreateShortcut()
    .TargetPath = "C:\WINDOWS\explorer.exe"
    .Arguments = "shell:AppsFolder\GPA.MeetingTranscriber_1.0.0.0_x64__1234567890abc"
    .IconLocation = "C:\WINDOWS\System32\SHELL32.dll,77"
    .Save()
    Write-Host "Start Menu shortcut created successfully." -ForegroundColor Green
} catch {
    Write-Host "Failed to create Start Menu shortcut: " -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Installation complete!" -ForegroundColor Green
Write-Host "You can now find Meeting Transcriber:" -ForegroundColor White
Write-Host "1. On your desktop (shortcut created)" -ForegroundColor White
Write-Host "2. In the Start menu (shortcut created)" -ForegroundColor White
Write-Host "3. By using the LaunchApp.bat file included in this folder" -ForegroundColor White
Write-Host ""
Write-Host "If you cannot find the application, try restarting your computer." -ForegroundColor Yellow
Write-Host ""
Read-Host "Press Enter to exit"
