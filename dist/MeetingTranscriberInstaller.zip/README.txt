# Meeting Transcriber Installer

## Installation Instructions

1. Extract all files from this ZIP archive to a folder
2. Right-click on Install.bat and select "Run as administrator"
3. Follow the on-screen instructions
4. The installer will:
   - Install the certificate to your trusted root store
   - Install the Meeting Transcriber application

## Troubleshooting

If you encounter installation issues:

1. Make sure you're running Install.bat as administrator
2. Try enabling Developer Mode:
   - Go to Settings > Update & Security > For developers
   - Turn on "Developer Mode"
3. If you see a signature validation error, the installer will automatically
   try to use the -AllowUntrusted flag to bypass this check
4. Check Windows Event Viewer for more detailed error messages

## System Requirements

- Windows 10 or Windows 11
- Internet connection for AWS services

## Support

For support, please contact: albaneg@yahoo.com
