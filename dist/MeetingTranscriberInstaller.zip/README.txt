# Meeting Transcriber Installer

## Installation Instructions

1. Extract all files from this ZIP archive to a folder
2. Run the Install.bat file
3. Allow administrative access when prompted
4. The installer will:
   - Install the certificate to your trusted root store
   - Install the Meeting Transcriber application
5. After installation, you can find Meeting Transcriber in your Start menu

## System Requirements

- Windows 10 or Windows 11
- Internet connection for AWS services

## Support

For support, please contact: albaneg@yahoo.com
